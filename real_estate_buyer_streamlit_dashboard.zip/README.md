# Real Estate Buyer Intelligence - Streamlit Dashboard

## Files required

Put these files in the same folder:

- app.py
- buyer_segmentation_results.csv
- cluster_profile.csv
- country_cluster_analysis.csv
- region_cluster_analysis.csv

## Run locally

Install dependencies:

pip install -r requirements.txt

Run:

streamlit run app.py

## Google Colab

The easiest option is to run the clustering notebook first, download the four
CSV output files, and place them beside app.py before deploying the dashboard.

## Dashboard modules

1. Buyer Segmentation Overview
2. Investor Behavior Dashboard
3. Geographic Buyer Analysis
4. Segment Insights Panel
5. Country / Region / Purpose / Client Type / Cluster filters
6. Filtered CSV download

## Important data limitation

The supplied client/property data does not contain income or net-worth fields.
Therefore, the dashboard does not label buyers as "high income" unless such a
field is added later. It uses observable property value and behavior instead.
