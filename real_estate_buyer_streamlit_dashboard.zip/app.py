
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from pathlib import Path

# ============================================================
# PAGE CONFIGURATION
# ============================================================
st.set_page_config(
    page_title="Real Estate Buyer Intelligence",
    page_icon="🏠",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ============================================================
# CUSTOM CSS
# ============================================================
st.markdown("""
<style>
    .main-title {
        font-size: 36px;
        font-weight: 700;
        margin-bottom: 0;
    }
    .sub-title {
        font-size: 16px;
        color: #666;
        margin-top: 0;
    }
    .metric-card {
        padding: 10px;
    }
</style>
""", unsafe_allow_html=True)

# ============================================================
# LOAD DATA
# ============================================================
@st.cache_data
def load_data():
    buyer_file = Path("buyer_segmentation_results.csv")
    profile_file = Path("cluster_profile.csv")
    country_file = Path("country_cluster_analysis.csv")
    region_file = Path("region_cluster_analysis.csv")

    missing = [
        str(f) for f in
        [buyer_file, profile_file, country_file, region_file]
        if not f.exists()
    ]

    if missing:
        return None, None, None, None, missing

    buyer = pd.read_csv(buyer_file)
    profile = pd.read_csv(profile_file)
    country = pd.read_csv(country_file, index_col=0)
    region = pd.read_csv(region_file, index_col=0)

    return buyer, profile, country, region, []


buyer, profile, country_cluster, region_cluster, missing_files = load_data()

# ============================================================
# HEADER
# ============================================================
st.markdown(
    '<p class="main-title">🏠 Real Estate Buyer Intelligence Dashboard</p>',
    unsafe_allow_html=True
)
st.markdown(
    '<p class="sub-title">Machine Learning Based Buyer Segmentation and Investment Profiling</p>',
    unsafe_allow_html=True
)

st.divider()

# ============================================================
# FILE CHECK
# ============================================================
if missing_files:
    st.error("Required output files are missing.")

    st.markdown("""
    Please place these four files in the same folder as `app.py`:

    1. `buyer_segmentation_results.csv`
    2. `cluster_profile.csv`
    3. `country_cluster_analysis.csv`
    4. `region_cluster_analysis.csv`

    Run the Google Colab clustering code first to create these files.
    """)

    st.stop()

# ============================================================
# DATA CLEANING FOR DASHBOARD
# ============================================================
buyer["cluster"] = buyer["cluster"].astype(int)

# Keep original cluster for filtering
all_clusters = sorted(buyer["cluster"].dropna().unique().tolist())

# ============================================================
# SIDEBAR FILTERS
# ============================================================
st.sidebar.title("🔎 Dashboard Filters")

countries = sorted(
    buyer["country"].dropna().astype(str).unique().tolist()
)
regions = sorted(
    buyer["region"].dropna().astype(str).unique().tolist()
)
purposes = sorted(
    buyer["acquisition_purpose"].dropna().astype(str).unique().tolist()
)
client_types = sorted(
    buyer["client_type"].dropna().astype(str).unique().tolist()
)

selected_country = st.sidebar.multiselect(
    "Country",
    countries,
    default=[]
)

selected_region = st.sidebar.multiselect(
    "Region",
    regions,
    default=[]
)

selected_purpose = st.sidebar.multiselect(
    "Acquisition Purpose",
    purposes,
    default=[]
)

selected_client_type = st.sidebar.multiselect(
    "Client Type",
    client_types,
    default=[]
)

selected_clusters = st.sidebar.multiselect(
    "Cluster",
    all_clusters,
    default=all_clusters
)

# ============================================================
# APPLY FILTERS
# ============================================================
filtered = buyer.copy()

if selected_country:
    filtered = filtered[
        filtered["country"].isin(selected_country)
    ]

if selected_region:
    filtered = filtered[
        filtered["region"].isin(selected_region)
    ]

if selected_purpose:
    filtered = filtered[
        filtered["acquisition_purpose"].isin(selected_purpose)
    ]

if selected_client_type:
    filtered = filtered[
        filtered["client_type"].isin(selected_client_type)
    ]

if selected_clusters:
    filtered = filtered[
        filtered["cluster"].isin(selected_clusters)
    ]

# ============================================================
# EMPTY DATA CHECK
# ============================================================
if filtered.empty:
    st.warning(
        "No buyers match the selected filters. "
        "Please change the filters."
    )
    st.stop()

# ============================================================
# KPI SECTION
# ============================================================
st.subheader("📊 Buyer Segmentation Overview")

total_buyers = len(filtered)
investment_buyers = int(filtered["is_investor"].sum())
loan_users = int(filtered["uses_loan"].sum())
company_buyers = int(filtered["is_company"].sum())

total_value = filtered["total_property_value"].sum()
avg_satisfaction = filtered["satisfaction_score"].mean()

c1, c2, c3, c4, c5 = st.columns(5)

c1.metric(
    "Total Buyers",
    f"{total_buyers:,}"
)

c2.metric(
    "Investment Buyers",
    f"{investment_buyers:,}"
)

c3.metric(
    "Loan Users",
    f"{loan_users:,}"
)

c4.metric(
    "Company Buyers",
    f"{company_buyers:,}"
)

c5.metric(
    "Avg Satisfaction",
    f"{avg_satisfaction:.2f}"
)

st.divider()

# ============================================================
# TABS
# ============================================================
tab1, tab2, tab3, tab4 = st.tabs([
    "📊 Buyer Segments",
    "💰 Investor Behavior",
    "🌍 Geographic Analysis",
    "💡 Segment Insights"
])

# ============================================================
# TAB 1 - BUYER SEGMENTS
# ============================================================
with tab1:

    col1, col2 = st.columns(2)

    with col1:
        cluster_counts = (
            filtered["cluster"]
            .value_counts()
            .sort_index()
            .reset_index()
        )

        cluster_counts.columns = [
            "cluster",
            "buyers"
        ]

        fig = px.pie(
            cluster_counts,
            names="cluster",
            values="buyers",
            title="Buyer Distribution by Cluster",
            hole=0.4
        )

        st.plotly_chart(
            fig,
            use_container_width=True
        )

    with col2:
        cluster_bar = (
            filtered["cluster"]
            .value_counts()
            .sort_index()
            .reset_index()
        )

        cluster_bar.columns = [
            "cluster",
            "buyers"
        ]

        fig = px.bar(
            cluster_bar,
            x="cluster",
            y="buyers",
            title="Number of Buyers by Cluster",
            text="buyers"
        )

        fig.update_layout(
            xaxis_title="Cluster",
            yaxis_title="Number of Buyers"
        )

        st.plotly_chart(
            fig,
            use_container_width=True
        )

    # PCA visualization if available
    st.subheader("Cluster Visualization")

    numeric_for_pca = [
        "age",
        "satisfaction_score",
        "property_count",
        "sold_property_count",
        "total_property_value",
        "average_property_price",
        "total_area_sqft",
        "average_area_sqft",
        "sold_ratio"
    ]

    available_numeric = [
        c for c in numeric_for_pca
        if c in filtered.columns
    ]

    if len(available_numeric) >= 2:

        # A simple normalized 2D visualization based on the first
        # two available numeric variables. This avoids retraining
        # the model inside Streamlit.
        x_col = "age" if "age" in filtered.columns else available_numeric[0]
        y_col = (
            "total_property_value"
            if "total_property_value" in filtered.columns
            else available_numeric[1]
        )

        fig = px.scatter(
            filtered,
            x=x_col,
            y=y_col,
            color=filtered["cluster"].astype(str),
            hover_data=[
                c for c in [
                    "client_id",
                    "country",
                    "region",
                    "acquisition_purpose",
                    "client_type"
                ]
                if c in filtered.columns
            ],
            title="Buyer Segments - Buyer Feature View",
            labels={"color": "Cluster"}
        )

        st.plotly_chart(
            fig,
            use_container_width=True
        )

# ============================================================
# TAB 2 - INVESTOR BEHAVIOR
# ============================================================
with tab2:

    col1, col2 = st.columns(2)

    with col1:
        purpose_data = pd.crosstab(
            filtered["cluster"],
            filtered["acquisition_purpose"]
        )

        purpose_data = purpose_data.reset_index()

        purpose_long = purpose_data.melt(
            id_vars="cluster",
            var_name="purpose",
            value_name="buyers"
        )

        fig = px.bar(
            purpose_long,
            x="cluster",
            y="buyers",
            color="purpose",
            barmode="group",
            title="Acquisition Purpose by Cluster"
        )

        st.plotly_chart(
            fig,
            use_container_width=True
        )

    with col2:
        loan_data = pd.crosstab(
            filtered["cluster"],
            filtered["loan_applied"]
        )

        loan_data = loan_data.reset_index()

        loan_long = loan_data.melt(
            id_vars="cluster",
            var_name="loan_status",
            value_name="buyers"
        )

        fig = px.bar(
            loan_long,
            x="cluster",
            y="buyers",
            color="loan_status",
            barmode="group",
            title="Loan Behavior by Cluster"
        )

        st.plotly_chart(
            fig,
            use_container_width=True
        )

    col3, col4 = st.columns(2)

    with col3:
        value_by_cluster = (
            filtered
            .groupby("cluster")["total_property_value"]
            .mean()
            .reset_index()
        )

        fig = px.bar(
            value_by_cluster,
            x="cluster",
            y="total_property_value",
            title="Average Property Value by Cluster",
            text_auto=".2s"
        )

        fig.update_yaxes(
            title="Average Total Property Value"
        )

        st.plotly_chart(
            fig,
            use_container_width=True
        )

    with col4:
        age_by_cluster = (
            filtered
            .groupby("cluster")["age"]
            .mean()
            .reset_index()
        )

        fig = px.bar(
            age_by_cluster,
            x="cluster",
            y="age",
            title="Average Buyer Age by Cluster",
            text_auto=".1f"
        )

        fig.update_yaxes(
            title="Average Age"
        )

        st.plotly_chart(
            fig,
            use_container_width=True
        )

    st.subheader("Investment Behavior Summary")

    behavior_columns = [
        "cluster",
        "age",
        "satisfaction_score",
        "property_count",
        "sold_property_count",
        "total_property_value",
        "average_property_price",
        "sold_ratio"
    ]

    behavior_columns = [
        c for c in behavior_columns
        if c in filtered.columns
    ]

    behavior_summary = (
        filtered
        .groupby("cluster")[behavior_columns[1:]]
        .mean()
        .reset_index()
        .round(2)
    )

    st.dataframe(
        behavior_summary,
        use_container_width=True,
        hide_index=True
    )

# ============================================================
# TAB 3 - GEOGRAPHIC ANALYSIS
# ============================================================
with tab3:

    st.subheader("🌍 Buyers by Country")

    country_counts = (
        filtered["country"]
        .value_counts()
        .reset_index()
    )

    country_counts.columns = [
        "country",
        "buyers"
    ]

    fig = px.bar(
        country_counts,
        x="country",
        y="buyers",
        title="Buyer Distribution by Country",
        text="buyers"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )

    # Country map where Plotly can recognize country names.
    st.subheader("🗺️ Global Buyer Distribution")

    try:
        fig = px.choropleth(
            country_counts,
            locations="country",
            locationmode="country names",
            color="buyers",
            hover_name="country",
            color_continuous_scale="Blues",
            title="Buyers by Country"
        )

        fig.update_layout(
            geo=dict(
                showframe=False,
                showcoastlines=True
            )
        )

        st.plotly_chart(
            fig,
            use_container_width=True
        )

    except Exception:
        st.info(
            "The country names could not be converted into a "
            "Plotly world map. The country bar chart above is still available."
        )

    st.subheader("📍 Buyers by Region")

    region_counts = (
        filtered["region"]
        .value_counts()
        .head(30)
        .reset_index()
    )

    region_counts.columns = [
        "region",
        "buyers"
    ]

    fig = px.bar(
        region_counts,
        x="buyers",
        y="region",
        orientation="h",
        title="Top 30 Regions by Buyer Count"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )

    st.subheader("Country × Cluster")

    country_cluster_filtered = pd.crosstab(
        filtered["country"],
        filtered["cluster"]
    )

    st.dataframe(
        country_cluster_filtered,
        use_container_width=True
    )

# ============================================================
# TAB 4 - SEGMENT INSIGHTS
# ============================================================
with tab4:

    st.subheader("💡 Cluster Profiles")

    profile_display = profile.copy()

    # Only display profiles for selected clusters
    if selected_clusters:
        profile_display = profile_display[
            profile_display["cluster"].isin(selected_clusters)
        ]

    st.dataframe(
        profile_display,
        use_container_width=True,
        hide_index=True
    )

    st.divider()

    st.subheader("🏷️ Suggested Buyer Segment Names")

    # Calculate characteristics from the filtered buyer data.
    segment_rows = []

    for cluster in sorted(filtered["cluster"].unique()):

        data = filtered[
            filtered["cluster"] == cluster
        ]

        investment_rate = data["is_investor"].mean() * 100
        loan_rate = data["uses_loan"].mean() * 100
        company_rate = data["is_company"].mean() * 100
        avg_value = data["total_property_value"].mean()
        avg_age = data["age"].mean()
        avg_properties = data["property_count"].mean()

        median_value = filtered["total_property_value"].median()

        if company_rate > 50 and avg_properties > 1:
            name = "Corporate / Company Buyers"
        elif investment_rate > 60 and avg_value >= median_value:
            name = "Investment-Oriented Buyers"
        elif loan_rate > 60 and avg_age < 45:
            name = "Younger / Loan-Dependent Buyers"
        elif avg_value >= filtered["total_property_value"].quantile(0.75):
            name = "High-Value Property Buyers"
        else:
            name = "General / Mixed Buyers"

        segment_rows.append({
            "Cluster": cluster,
            "Suggested Segment": name,
            "Buyers": len(data),
            "Investment Rate (%)": round(investment_rate, 2),
            "Loan Rate (%)": round(loan_rate, 2),
            "Company Rate (%)": round(company_rate, 2),
            "Average Age": round(avg_age, 2),
            "Average Property Count": round(avg_properties, 2),
            "Average Property Value": round(avg_value, 2)
        })

    segment_table = pd.DataFrame(segment_rows)

    st.dataframe(
        segment_table,
        use_container_width=True,
        hide_index=True
    )

    st.info(
        "Important: the dataset does not contain income or net-worth fields. "
        "Therefore, segment names use observable property value, investment "
        "behavior, financing behavior, age, and client type rather than "
        "claiming unobserved income levels."
    )

# ============================================================
# DOWNLOAD SECTION
# ============================================================
st.divider()

st.subheader("⬇️ Download Filtered Data")

csv_data = filtered.to_csv(index=False).encode("utf-8")

st.download_button(
    label="Download Filtered Buyer Data",
    data=csv_data,
    file_name="filtered_buyer_segmentation.csv",
    mime="text/csv"
)

# ============================================================
# FOOTER
# ============================================================
st.divider()

st.caption(
    "Real Estate Buyer Intelligence | "
    "K-Means Buyer Segmentation | "
    "Investment Profiling"
)
